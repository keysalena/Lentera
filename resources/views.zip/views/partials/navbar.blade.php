<nav>
    <div class="nav-inner">
        <a class="logo" href="#">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L15 8.5L22 9.5L17 14.5L18.5 21.5L12 18L5.5 21.5L7 14.5L2 9.5L9 8.5L12 2Z" stroke="currentColor" class="nav-logo-img" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <!-- <img src="https://lh3.googleusercontent.com/aida/AP1WRLuQ1ntuLdYwaaZ46xJB8_9nLPmlf87586yXnCAyer4-MTDCqUnsfpDtQadGdxw9J8BFNJrREw9VDu5VjN3Ma3Dt1u240OQupDzc8Y90gNq_gLqa26h-zMKwBDGOwTlfDO_sD3cj4S3SEdRRkLAv-o5AnnFwyVWm0--TBxxTK3pU89GoIYOgqPVpoIyYARc2zBiNp73Oxr08IAVFw5oLAjLQRNio2gEG_ApB9dgAnH-8ohXftXngPz5sfj4"
                alt="Logo LENTERA" class="nav-logo-img"> -->
            <span class="logo-name">LENTERA</span>
        </a>
        <ul class="nav-links">
            <li>
                <a href="{{ url('/') }}" class="{{ request()->is('/') ? 'active' : '' }}">Beranda</a>
            </li>
            <li>
                <a href="{{ url('/tentang') }}" class="{{ request()->is('tentang') ? 'active' : '' }}">Tentang</a>
            </li>
        </ul>
        <div class="nav-actions">
            <a href="/masuk" class="btn-ghost">Masuk</a>
            <a href="/masuk" class="btn-primary">Mulai Analisis</a>
        </div>
    </div>
</nav>