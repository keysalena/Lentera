@extends('layouts.admin')

@section('dashboard_content')
<div class="admin-sekolah" style="animation: fadeIn 0.4s ease-in-out;">
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; flex-wrap: wrap; gap: 20px;">
        <div>
            <h2 style="font-family: 'DM Serif Display', serif; font-size: 28px; color: var(--ink);">Data Mitra Sekolah</h2>
            <p style="font-size: 14px; color: var(--ink-60);">Kelola instansi dan pengguna platform LENTERA.</p>
        </div>
        
        <div style="display: flex; gap: 16px; align-items: center;">
            <input type="text" placeholder="Cari nama sekolah..." 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; width: 240px; outline: none; font-size: 13px;">
            
            <button style="background: var(--amber); color: var(--white); border: none; padding: 12px 20px; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; transition: opacity 0.2s; display: flex; align-items: center; gap: 8px;" onmouseover="this.style.opacity='0.9';" onmouseout="this.style.opacity='1';">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 18px; height: 18px;">
                    <path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Tambah Mitra Baru
            </button>
        </div>
    </div>

    <div style="background: var(--white); border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25); overflow: hidden;">
        <table style="width: 100%; border-collapse: collapse;">
            <thead style="background: var(--cream);">
                <tr>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">INFORMASI SEKOLAH</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">TOTAL GURU BK</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">TOTAL SISWA</th>
                    <th style="padding: 16px 24px; text-align: right; font-size: 12px; color: var(--ink-60);">TINDAKAN</th>
                </tr>
            </thead>
            <tbody>
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink); font-size: 15px;">SMAN 1 Malang</div>
                        <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">Terdaftar: 10 Jan 2026</div>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="font-size: 14px; font-weight: 600; color: var(--ink);">4 Akun</div>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="font-size: 14px; font-weight: 600; color: var(--ink);">850 Siswa</div>
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 12px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Edit</a>
                            <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail</a>
                        </div>
                    </td>
                </tr>

                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink); font-size: 15px;">SMAN 3 Malang</div>
                        <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">Terdaftar: 15 Feb 2026</div>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="font-size: 14px; font-weight: 600; color: var(--ink);">6 Akun</div>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="font-size: 14px; font-weight: 600; color: var(--ink);">1,180 Siswa</div>
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 12px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Edit</a>
                            <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail</a>
                        </div>
                    </td>
                </tr>

                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink); font-size: 15px;">SMA Swasta Harapan</div>
                        <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">Terdaftar: 01 Mar 2025</div>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="font-size: 14px; font-weight: 600; color: var(--ink);">2 Akun</div>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="font-size: 14px; font-weight: 600; color: var(--ink);">120 Siswa</div>
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 12px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Edit</a>
                            <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail</a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

</div>
@endsection