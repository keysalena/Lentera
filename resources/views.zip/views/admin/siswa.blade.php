@extends('layouts.admin')

@section('dashboard_content')
<div class="admin-siswa" style="animation: fadeIn 0.4s ease-in-out;">
    
    <!-- ── HEADER & FILTER BAR ── -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; flex-wrap: wrap; gap: 16px;">
        <div>
            <h2 style="font-family: 'DM Serif Display', serif; font-size: 28px; color: var(--ink);">Data Seluruh Siswa</h2>
            <p style="font-size: 14px; color: var(--ink-60);">Pantau dan kelola akun siswa dari seluruh sekolah mitra.</p>
        </div>
        
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <!-- Filter Asal Sekolah -->
            <select name="filter_sekolah" 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 13px; background: var(--white); color: var(--ink); outline: none; cursor: pointer; min-width: 160px;">
                <option value="all">Semua Sekolah</option>
                <option value="sman1">SMAN 1 Malang</option>
                <option value="sman3">SMAN 3 Malang</option>
                <option value="sman4">SMAN 4 Malang</option>
            </select>

            <!-- Filter Angkatan -->
            <select name="filter_angkatan" 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 13px; background: var(--white); color: var(--ink); outline: none; cursor: pointer; min-width: 140px;">
                <option value="all">Semua Angkatan</option>
                <option value="2026">Masuk 2026</option>
                <option value="2025">Masuk 2025</option>
                <option value="2024">Masuk 2024</option>
            </select>

            <!-- Kolom Pencarian -->
            <input type="text" placeholder="Cari nama atau email..." 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; width: 240px; outline: none; font-size: 13px;">
        </div>
    </div>

    <!-- ── TABEL DATA SELURUH SISWA ── -->
    <div style="background: var(--white); border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25); overflow: hidden;">
        <table style="width: 100%; border-collapse: collapse;">
            <thead style="background: var(--cream);">
                <tr>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">NAMA SISWA</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">ASAL SEKOLAH</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">ANGKATAN</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">STATUS DATA</th>
                    <th style="padding: 16px 24px; text-align: right; font-size: 12px; color: var(--ink-60);">TINDAKAN</th>
                </tr>
            </thead>
            <tbody>
                <!-- Baris 1: Lengkap -->
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink);">Keysa Lena Misdona</div>
                        <div style="font-size: 12px; color: var(--ink-60);">keysa.misdona@student.um.ac.id</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        SMAN 1 Malang
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; color: var(--ink-60);">
                        2024
                    </td>
                    <td style="padding: 20px 24px;">
                        <span style="background: #E0F2FE; color: #0284C7; padding: 4px 10px; border-radius: 99px; font-size: 11px; font-weight: 700;">LENGKAP</span>
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail Akun</a>
                    </td>
                </tr>

                <!-- Baris 2: Progres -->
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink);">Budi Santoso</div>
                        <div style="font-size: 12px; color: var(--ink-60);">budi.s@student.um.ac.id</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        SMAN 3 Malang
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; color: var(--ink-60);">
                        2025
                    </td>
                    <td style="padding: 20px 24px;">
                        <span style="background: #FFF7ED; color: #EA580C; padding: 4px 10px; border-radius: 99px; font-size: 11px; font-weight: 700;">PROGRES</span>
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail Akun</a>
                    </td>
                </tr>

                <!-- Baris 3: Lengkap -->
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink);">Siti Aminah</div>
                        <div style="font-size: 12px; color: var(--ink-60);">siti.aminah@student.um.ac.id</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        SMAN 4 Malang
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; color: var(--ink-60);">
                        2026
                    </td>
                    <td style="padding: 20px 24px;">
                        <span style="background: #E0F2FE; color: #0284C7; padding: 4px 10px; border-radius: 99px; font-size: 11px; font-weight: 700;">LENGKAP</span>
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail Akun</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- ── PAGINASI ── -->
    <div style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center;">
        <div style="font-size: 13px; color: var(--ink-60);">
            Menampilkan 1 hingga 10 dari 2,845 siswa
        </div>
        <div style="display: flex; gap: 8px;">
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600; color: var(--ink-60);">Sebelumnya</button>
            <button style="padding: 8px 16px; border: 1px solid var(--amber); border-radius: 8px; background: var(--amber-bg); color: var(--amber); cursor: pointer; font-size: 13px; font-weight: 700;">1</button>
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600;">2</button>
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600;">3</button>
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600; color: var(--ink);">Selanjutnya</button>
        </div>
    </div>

</div>
@endsection