@extends('layouts.admin')

@section('dashboard_content')
<div class="admin-guru" style="animation: fadeIn 0.4s ease-in-out;">
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; flex-wrap: wrap; gap: 20px;">
        <div>
            <h2 style="font-family: 'DM Serif Display', serif; font-size: 28px; color: var(--ink);">Data Guru BK</h2>
            <p style="font-size: 14px; color: var(--ink-60);">Kelola akses dan akun pendidik dari seluruh sekolah mitra.</p>
        </div>
        
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <select name="filter_sekolah" 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 13px; background: var(--white); color: var(--ink); outline: none; cursor: pointer; min-width: 160px;">
                <option value="all">Semua Sekolah</option>
                <option value="sman1">SMAN 1 Malang</option>
                <option value="sman3">SMAN 3 Malang</option>
                <option value="sman4">SMAN 4 Malang</option>
            </select>

            <input type="text" placeholder="Cari nama atau email guru..." 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; width: 240px; outline: none; font-size: 13px;">
            
            <button style="background: var(--amber); color: var(--white); border: none; padding: 12px 20px; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; transition: opacity 0.2s; display: flex; align-items: center; gap: 8px;" onmouseover="this.style.opacity='0.9';" onmouseout="this.style.opacity='1';">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 18px; height: 18px;">
                    <path d="M12 5V19M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Tambah Akun Guru
            </button>
        </div>
    </div>

    <div style="background: var(--white); border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25); overflow: hidden;">
        <table style="width: 100%; border-collapse: collapse;">
            <thead style="background: var(--cream);">
                <tr>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">NAMA LENGKAP</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">ASAL SEKOLAH</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">SISWA DIDIKAN</th>
                    <th style="padding: 16px 24px; text-align: right; font-size: 12px; color: var(--ink-60);">TINDAKAN</th>
                </tr>
            </thead>
            <tbody>
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink); font-size: 14px;">Ahmad Rizky, M.Pd.</div>
                        <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">ahmad.rizky@sman1mlg.sch.id</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        SMAN 1 Malang
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; color: var(--ink-60);">
                        248 Siswa
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 12px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Edit</a>
                            <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail Akun</a>
                        </div>
                    </td>
                </tr>

                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink); font-size: 14px;">Siti Nurhaliza, S.Psi.</div>
                        <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">siti.nurhaliza@sman3mlg.sch.id</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        SMAN 3 Malang
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; color: var(--ink-60);">
                        312 Siswa
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 12px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Edit</a>
                            <a href="#" style="color: var(--amber); font-weight: 600; font-size: 13px; text-decoration: none;">Detail Akun</a>
                        </div>
                    </td>
                </tr>

                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink); font-size: 14px;">Budi Mulyono, S.Pd.</div>
                        <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">budi.mulyono@smaswasta.sch.id</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        SMA Swasta Harapan
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; color: var(--ink-60);">
                        0 Siswa
                    </td>
                    <td style="padding: 20px 24px; text-align: right;">
                        <div style="display: flex; justify-content: flex-end; gap: 12px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Edit</a>
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none;">Detail Akun</a>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 24px; display: flex; justify-content: space-between; align-items: center;">
        <div style="font-size: 13px; color: var(--ink-60);">
            Menampilkan 1 hingga 10 dari 42 guru
        </div>
        <div style="display: flex; gap: 8px;">
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600; color: var(--ink-60);">Sebelumnya</button>
            <button style="padding: 8px 16px; border: 1px solid var(--amber); border-radius: 8px; background: var(--amber-bg); color: var(--amber); cursor: pointer; font-size: 13px; font-weight: 700;">1</button>
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600;">2</button>
            <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer; font-size: 13px; font-weight: 600; color: var(--ink);">Selanjutnya</button>
        </div>
    </div>

</div>
@endsection