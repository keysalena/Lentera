@extends('layouts.guru')

@section('dashboard_content')
<div class="guru-summary" style="animation: fadeIn 0.4s ease-in-out;">
    
    <!-- ── HEADER & FILTER BAR ── -->
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 32px; flex-wrap: wrap; gap: 20px;">
        <div>
            <h2 style="font-family: 'DM Serif Display', serif; font-size: 32px; color: var(--ink); margin-bottom: 8px;">
                Dashboard Monitoring BK
            </h2>
            <p style="font-size: 15px; color: var(--ink-60);">
                Pantau hasil analisis eksplorasi karier siswa <span style="font-weight: 700; color: var(--amber);">SMAN 1 Malang</span>.
            </p>
        </div>

        <div style="display: flex; gap: 12px;">
            <select name="filter_tahun" style="padding: 10px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 13px; background: var(--white); color: var(--ink); outline: none; cursor: pointer; min-width: 160px;">
                <option value="all">Semua Angkatan</option>
                <option value="2026">Masuk 2026</option>
                <option value="2025">Masuk 2025</option>
                <option value="2024">Masuk 2024</option>
            </select>
        </div>
    </div>

    <!-- ── STATISTIK CEPAT ── -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px;">
        
        <!-- Statistik 1: Total Partisipasi -->
        <div style="background: var(--white); padding: 24px; border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25);">
            <h4 style="font-size: 12px; font-weight: 700; color: var(--ink-60); text-transform: uppercase; margin-bottom: 8px;">Total Partisipasi</h4>
            <div style="font-size: 32px; font-weight: 800; color: var(--ink);">196</div>
            <p style="font-size: 12px; color: var(--ink-30);">Siswa selesai mengikuti tes</p>
        </div>

        <!-- Statistik 2: Tren Karier Terbanyak -->
        <div style="background: var(--white); padding: 24px; border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25);">
            <h4 style="font-size: 12px; font-weight: 700; color: var(--amber); text-transform: uppercase; margin-bottom: 8px;">Dominansi Bidang</h4>
            <div style="font-size: 32px; font-weight: 800; color: var(--amber);">STEM</div>
            <p style="font-size: 12px; color: var(--ink-30);">Rekomendasi jurusan terbanyak</p>
        </div>

        <!-- Statistik 3: Laporan Diakses -->
        <div style="background: var(--white); padding: 24px; border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25);">
            <h4 style="font-size: 12px; font-weight: 700; color: #10B981; text-transform: uppercase; margin-bottom: 8px;">Laporan Diakses</h4>
            <div style="font-size: 32px; font-weight: 800; color: #10B981;">152</div>
            <p style="font-size: 12px; color: var(--ink-30);">Siswa telah melihat hasil akhirnya</p>
        </div>
    </div>

    <!-- ── AKTIVITAS TERKINI ── -->
    <div style="background: var(--white); padding: 32px; border-radius: 20px; border: 1px solid rgba(171, 168, 159, 0.25);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
            <h3 style="font-size: 18px; font-weight: 700; color: var(--ink);">Aktivitas Tes Terkini</h3>
            <a href="#" style="font-size: 13px; color: var(--amber); font-weight: 600; text-decoration: none;">Lihat Semua</a>
        </div>

        <div style="display: flex; flex-direction: column; gap: 16px;">
            
            <!-- Baris Aktivitas 1: Selesai Input Tes -->
            <div style="display: flex; align-items: center; gap: 16px; padding: 12px 0; border-bottom: 1px solid var(--cream);">
                <div style="width: 36px; height: 36px; border-radius: 50%; background: var(--amber-bg); display: flex; align-items: center; justify-content: center; color: var(--amber);">
                    <!-- Icon Edit/Test -->
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 18px; height: 18px;">
                        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" />
                        <path d="M12 6V12L16 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                    </svg>
                </div>
                <div style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 14px; font-weight: 600; color: var(--ink);">Keysa Lena Misdona</span>
                        <span style="font-size: 10px; font-weight: 700; background: var(--cream); color: var(--ink-60); padding: 2px 8px; border-radius: 6px;">2024</span>
                    </div>
                    <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">
                        Selesai menyelesaikan tes eksplorasi karier.
                    </div>
                </div>
                <div style="font-size: 12px; color: var(--ink-30); font-weight: 500;">5 menit lalu</div>
            </div>

            <!-- Baris Aktivitas 2: Melihat Hasil -->
            <div style="display: flex; align-items: center; gap: 16px; padding: 12px 0;">
                <div style="width: 36px; height: 36px; border-radius: 50%; background: #E0F2FE; display: flex; align-items: center; justify-content: center; color: #0284C7;">
                    <!-- Icon Eye/View -->
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 18px; height: 18px;">
                        <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 14px; font-weight: 600; color: var(--ink);">Budi Santoso</span>
                        <span style="font-size: 10px; font-weight: 700; background: var(--cream); color: var(--ink-60); padding: 2px 8px; border-radius: 6px;">2025</span>
                    </div>
                    <div style="font-size: 12px; color: var(--ink-60); margin-top: 2px;">
                        Mengakses laporan hasil rekomendasi sistem.
                    </div>
                </div>
                <div style="font-size: 12px; color: var(--ink-30); font-weight: 500;">2 jam lalu</div>
            </div>

        </div>
    </div>
</div>
@endsection