@extends('layouts.guru')

@section('dashboard_content')
<div class="guru-siswa" style="animation: fadeIn 0.4s ease-in-out;">
    
    <!-- ── HEADER & FILTER BAR ── -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; flex-wrap: wrap; gap: 16px;">
        <div>
            <h2 style="font-family: 'DM Serif Display', serif; font-size: 28px; color: var(--ink);">Daftar Siswa</h2>
            <p style="font-size: 14px; color: var(--ink-60);">Kelola dan pantau seluruh data eksplorasi siswa.</p>
        </div>
        
        <div style="display: flex; gap: 12px; align-items: center;">
            <!-- Dropdown Filter Angkatan -->
            <select name="filter_angkatan" 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 14px; background: var(--white); color: var(--ink); outline: none; cursor: pointer; min-width: 160px;">
                <option value="all">Semua Angkatan</option>
                <option value="2026">Masuk 2026</option>
                <option value="2025">Masuk 2025</option>
                <option value="2024">Masuk 2024</option>
            </select>

            <!-- Kolom Pencarian -->
            <input type="text" placeholder="Cari nama siswa..." 
                style="padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; width: 260px; outline: none; font-size: 14px;">
        </div>
    </div>

    <!-- ── TABEL DATA SISWA ── -->
    <div style="background: var(--white); border-radius: 16px; border: 1px solid rgba(171, 168, 159, 0.25); overflow: hidden;">
        <table style="width: 100%; border-collapse: collapse;">
            <thead style="background: var(--cream);">
                <tr>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">NAMA SISWA</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">ANGKATAN MASUK</th>
                    <th style="padding: 16px 24px; text-align: left; font-size: 12px; color: var(--ink-60);">STATUS DATA</th>
                    <th style="padding: 16px 24px; text-align: right; font-size: 12px; color: var(--ink-60);">TINDAKAN</th>
                </tr>
            </thead>
            <tbody>
                <!-- Siswa 1: Data Lengkap -->
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink);">Keysa Lena Misdona</div>
                        <div style="font-size: 12px; color: var(--ink-60);">keysa.misdona@gamil.com</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        2024
                    </td>
                    <td style="padding: 20px 24px;">
                        <span style="background: #E0F2FE; color: #0284C7; padding: 4px 10px; border-radius: 99px; font-size: 11px; font-weight: 700;">LENGKAP</span>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="display: flex; justify-content: flex-end; align-items: center; gap: 16px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='var(--ink)';" onmouseout="this.style.color='var(--ink-60)';">Profil</a>
                            <a href="#" style="background: var(--amber); color: var(--white); padding: 8px 16px; border-radius: 8px; font-weight: 600; font-size: 12px; text-decoration: none; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.9';" onmouseout="this.style.opacity='1';">Tinjau Hasil</a>
                        </div>
                    </td>
                </tr>

                <!-- Siswa 2: Data Belum Lengkap (Progres) -->
                <tr style="border-top: 1px solid var(--cream);">
                    <td style="padding: 20px 24px;">
                        <div style="font-weight: 700; color: var(--ink);">Budi Santoso</div>
                        <div style="font-size: 12px; color: var(--ink-60);">budi.santoso@gmail.com</div>
                    </td>
                    <td style="padding: 20px 24px; font-size: 14px; font-weight: 600; color: var(--ink);">
                        2025
                    </td>
                    <td style="padding: 20px 24px;">
                        <span style="background: #FFF7ED; color: #EA580C; padding: 4px 10px; border-radius: 99px; font-size: 11px; font-weight: 700;">PROGRES</span>
                    </td>
                    <td style="padding: 20px 24px;">
                        <div style="display: flex; justify-content: flex-end; align-items: center; gap: 16px;">
                            <a href="#" style="color: var(--ink-60); font-weight: 600; font-size: 13px; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='var(--ink)';" onmouseout="this.style.color='var(--ink-60)';">Profil</a>
                            <!-- Tombol disabled untuk status PROGRES -->
                            <span style="background: var(--paper); color: var(--ink-30); border: 1px solid var(--cream); padding: 8px 16px; border-radius: 8px; font-weight: 600; font-size: 12px; cursor: not-allowed;" title="Siswa belum menyelesaikan input data">Tinjau Hasil</span>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Paginasi -->
    <div style="margin-top: 24px; display: flex; justify-content: center; gap: 8px;">
        <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer;">Previous</button>
        <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer;">1</button>
        <button style="padding: 8px 16px; border: 1px solid var(--cream); border-radius: 8px; background: var(--white); cursor: pointer;">Next</button>
    </div>

</div>
@endsection