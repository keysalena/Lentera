<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>@yield('title', 'LENTERA — Daftar')</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet" />

    <link rel="stylesheet" href="/css/style.css?v={{ time() }}">
</head>

<body>
    <div style="background: var(--cream); min-height: calc(100vh - 72px); display: flex; align-items: center; justify-content: center; padding: 40px 24px;">
        <div class="auth-container" style="background: var(--white); width: 100%; max-width: 520px; padding: 40px; border-radius: 20px; border: 1px solid rgba(171, 168, 159, 0.25); box-shadow: 0 12px 32px rgba(87, 94, 112, 0.06);">

            <div style="text-align: center; margin-bottom: 32px;">
                <div style="width: 48px; height: 48px; background: var(--amber); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
                    <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 24px; height: 24px;">
                        <path d="M10 2L12.5 7.5L18 8.5L14 12.5L15 18L10 15.5L5 18L6 12.5L2 8.5L7.5 7.5L10 2Z" fill="white" />
                    </svg>
                </div>
                <h2 style="font-family: 'DM Serif Display', serif; font-size: 28px; color: var(--ink); margin-bottom: 8px;">Buat Akun LENTERA</h2>
                <p style="font-size: 14px; color: var(--ink-60);">Lengkapi data di bawah untuk memulai eksplorasi kariermu</p>
            </div>

            <form action="#" method="POST" style="display: flex; flex-direction: column; gap: 20px;">
                @csrf

                <div>
                    <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Daftar Sebagai</label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <label style="border: 2px solid var(--cream); background: var(--paper); padding: 12px; border-radius: 10px; display: flex; align-items: center; gap: 8px; cursor: pointer; justify-content: center; transition: all 0.2s;">
                            <input type="radio" name="role" value="siswa" checked style="accent-color: var(--amber);">
                            <span style="font-size: 14px; font-weight: 600; color: var(--ink);">Siswa</span>
                        </label>
                        <label style="border: 2px solid var(--cream); background: var(--paper); padding: 12px; border-radius: 10px; display: flex; align-items: center; gap: 8px; cursor: pointer; justify-content: center; transition: all 0.2s;">
                            <input type="radio" name="role" value="guru" style="accent-color: var(--amber);">
                            <span style="font-size: 14px; font-weight: 600; color: var(--ink-60);">Guru BK</span>
                        </label>
                    </div>
                </div>

                <div>
                    <label for="name" style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 6px;">Nama Lengkap</label>
                    <input type="text" id="name" name="name" required placeholder="Contoh: Keysa Lena Misdona"
                        style="width: 100%; padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 14px; background: var(--paper); color: var(--ink); outline: none; transition: border-color 0.2s;">
                </div>

                <div>
                    <label for="email" style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 6px;">Alamat Email</label>
                    <input type="email" id="email" name="email" required placeholder="nama@sekolah.sch.id"
                        style="width: 100%; padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 14px; background: var(--paper); color: var(--ink); outline: none; transition: border-color 0.2s;">
                </div>

                <!-- Dropdown Asal Sekolah (Baru Ditambahkan) -->
                <div>
                    <label for="school" style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 6px;">Asal Sekolah</label>
                    <select id="school" name="school" required
                        style="width: 100%; padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 14px; background: var(--paper); color: var(--ink); outline: none; transition: border-color 0.2s; cursor: pointer;">
                        <option value="" disabled selected>Pilih asal sekolahmu...</option>
                        <option value="sman1">SMAN 1 Malang</option>
                        <option value="sman3">SMAN 3 Malang</option>
                        <option value="sman4">SMAN 4 Malang</option>
                        <option value="other">Sekolah Lainnya...</option>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div>
                        <label for="password" style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 6px;">Kata Sandi</label>
                        <input type="password" id="password" name="password" required placeholder="Minimal 8 karakter"
                            style="width: 100%; padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 14px; background: var(--paper); color: var(--ink); outline: none; transition: border-color 0.2s;">
                    </div>

                    <div>
                        <label for="password_confirmation" style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 6px;">Konfirmasi Sandi</label>
                        <input type="password" id="password_confirmation" name="password_confirmation" required placeholder="Ulangi kata sandi"
                            style="width: 100%; padding: 12px 16px; border: 1px solid var(--ink-30); border-radius: 10px; font-size: 14px; background: var(--paper); color: var(--ink); outline: none; transition: border-color 0.2s;">
                    </div>
                </div>

                <div style="display: flex; align-items: flex-start; gap: 10px; margin-top: 4px;">
                    <input type="checkbox" id="terms" name="terms" required style="margin-top: 4px; accent-color: var(--amber);">
                    <label for="terms" style="font-size: 13px; color: var(--ink-60); line-height: 1.5;">
                        Saya menyetujui <a href="#" style="color: var(--amber); font-weight: 600; text-decoration: none;">Syarat & Ketentuan</a> serta <a href="#" style="color: var(--amber); font-weight: 600; text-decoration: none;">Kebijakan Privasi</a> LENTERA.
                    </label>
                </div>

                <div style="margin-top: 8px;">
                    <button type="submit" class="btn-primary" style="width: 100%; padding: 14px; font-size: 15px; border-radius: 12px; font-weight: 700;">
                        Buat Akun Baru
                    </button>
                </div>
            </form>

            <div style="text-align: center; margin-top: 24px; padding-top: 24px; border-top: 1px solid var(--cream);">
                <p style="font-size: 14px; color: var(--ink-60);">
                    Sudah memiliki akun? <a href="/masuk" style="color: var(--amber); font-weight: 700; text-decoration: none;">Masuk di sini</a>
                </p>
            </div>

        </div>
    </div>
</body>

</html>