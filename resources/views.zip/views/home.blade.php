@extends('layouts.app')

@section('title', 'LENTERA - Beranda')

@section('content')

<header>
    <div class="hero">
        <div>
            <div class="hero-badge">
                <span class="hero-badge-dot"></span>
                AI-Powered Guidance
            </div>
            <h1>Pilih Jurusan yang <em>Benar-benar</em> Cocok Untukmu</h1>
            <p>LENTERA membaca nilai akademikmu, pola tulisan tangan, dan sertifikat prestasi — lalu memberikan rekomendasi jurusan kuliah yang paling sesuai, bukan sekadar tebakan.</p>
            <div class="hero-actions">
                <a href="/masuk" class="btn-cta">
                    Mulai Analisis
                    <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 8H13M13 8L9 4M13 8L9 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </a>
                <a href="#cara-kerja" class="btn-secondary">Lihat Cara Kerja</a>
            </div>
        </div>

        <div class="hero-right">
            <div class="hero-image-wrapper">
                <div class="pulse-ring ring-1"></div>
                <div class="pulse-ring ring-2"></div>
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L15 8.5L22 9.5L17 14.5L18.5 21.5L12 18L5.5 21.5L7 14.5L2 9.5L9 8.5L12 2Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" class="hero-main-img"/>
                </svg>
                <!-- <img src="https://lh3.googleusercontent.com/aida/AP1WRLuQ1ntuLdYwaaZ46xJB8_9nLPmlf87586yXnCAyer4-MTDCqUnsfpDtQadGdxw9J8BFNJrREw9VDu5VjN3Ma3Dt1u240OQupDzc8Y90gNq_gLqa26h-zMKwBDGOwTlfDO_sD3cj4S3SEdRRkLAv-o5AnnFwyVWm0--TBxxTK3pU89GoIYOgqPVpoIyYARc2zBiNp73Oxr08IAVFw5oLAjLQRNio2gEG_ApB9dgAnH-8ohXftXngPz5sfj4"
                    alt="Ilustrasi LENTERA" class="hero-main-img"> -->
            </div>
        </div>
    </div>
</header>

<!-- <div class="stats-bar">
        <div class="stats-inner">
            <div class="stat-item">
                <div class="stat-num">12<span>K+</span></div>
                <div class="stat-label">Siswa terbantu</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">200<span>+</span></div>
                <div class="stat-label">Jurusan dalam database</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">94<span>%</span></div>
                <div class="stat-label">Tingkat kepuasan siswa</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">350<span>+</span></div>
                <div class="stat-label">Sekolah mitra</div>
            </div>
        </div>
    </div> -->

<section class="section" id="cara-kerja">
    <div class="section-eyebrow">Cara Kerja</div>
    <div style="display:flex; align-items:flex-end; justify-content:space-between; gap:24px; flex-wrap:wrap;">
        <div>
            <h2 class="section-title">Tiga langkah menuju<br>pilihan yang tepat</h2>
        </div>
        <p class="section-sub" style="margin-top:0; padding-bottom:4px;">Prosesnya sederhana — input datamu, biarkan AI bekerja, dan dapatkan rekomendasi yang personal.</p>
    </div>

    <div class="steps">
        <div class="step">
            <div class="step-num">01</div>
            <div class="step-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 12H15M9 8H15M9 16H12M5 4H19C19.55 4 20 4.45 20 5V19C20 19.55 19.55 20 19 20H5C4.45 20 4 19.55 4 19V5C4 4.45 4.45 4 5 4Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
            <h3>Input Data Akademik</h3>
            <p>Masukkan nilai rapor per mata pelajaran, atau upload file rapor langsung. LENTERA membaca rekam jejak akademismu secara menyeluruh.</p>
        </div>
        <div class="step">
            <div class="step-num">02</div>
            <div class="step-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 17C5 17 5 15 7 15C9 15 9 17 11 17C13 17 13 15 15 15C17 15 17 17 19 17M3 12C5 12 5 10 7 10C9 10 9 12 11 12C13 12 13 10 15 10C17 10 17 12 19 12M3 7C5 7 5 5 7 5C9 5 9 7 11 7C13 7 13 5 15 5C17 5 17 7 19 7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" />
                </svg>
            </div>
            <h3>Upload Tulisan Tangan</h3>
            <p>Tulis kalimat pendek di kertas, foto, lalu upload. Sistem Computer Vision kami menganalisis pola grafologi untuk memahami kepribadian dan gaya belajarmu.</p>
        </div>
        <div class="step">
            <div class="step-num">03</div>
            <div class="step-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L15 8.5L22 9.5L17 14.5L18.5 21.5L12 18L5.5 21.5L7 14.5L2 9.5L9 8.5L12 2Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
            <h3>Terima Rekomendasi</h3>
            <p>AI kami menggabungkan semua data dan menghasilkan daftar jurusan yang cocok, lengkap dengan skor kecocokan, alasan, dan rekomendasi universitas.</p>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0;">
    <div class="section-eyebrow">Fitur</div>
    <h2 class="section-title">Analisis yang lebih dalam<br>dari sekadar nilai</h2>

    <div class="features-grid">
        <div class="feat-card accent">
            <div class="feat-tag">Computer Vision</div>
            <h3>Baca Karakter dari Tulisan Tangan</h3>
            <p>Grafologi berbasis AI mengidentifikasi sifat analitis, kreativitas, dan ketekunan — dimensi yang tidak tercermin dari nilai saja.</p>
            <div class="feat-deco">
                <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 28C14 28 14 22 18 22C22 22 22 28 28 28M8 20C14 20 14 14 18 14C22 14 22 20 28 20M8 12C14 12 14 8 18 8C22 8 22 12 28 12" stroke="rgba(245,192,122,0.4)" stroke-width="2" stroke-linecap="round" />
                </svg>
            </div>
        </div>
        <div class="feat-card">
            <div class="feat-tag">Academic Analytics</div>
            <h3>Analisis Nilai Lintas Mata Pelajaran</h3>
            <p>Sistem kami mengenali pola kekuatan akademik, bukan hanya melihat rata-rata. Nilai Matematika tinggi tapi Fisika rendah? Itu informasi yang berarti.</p>
            <div class="feat-deco">
                <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8 26L14 18L20 22L28 10" stroke="rgba(201,123,42,0.35)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </div>
        </div>
        <div class="feat-card">
            <div class="feat-tag">OCR — Opsional</div>
            <h3>Sertifikat Prestasi Diakui Otomatis</h3>
            <p>Upload piagam atau sertifikat lomba, kursus, atau organisasi. OCR kami membaca dan mengkategorikan bidang keunggulan untuk memperkuat rekomendasimu.</p>
            <div class="feat-deco">
                <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="8" y="6" width="20" height="24" rx="3" stroke="rgba(201,123,42,0.35)" stroke-width="2" />
                    <path d="M12 13H24M12 18H24M12 23H18" stroke="rgba(201,123,42,0.35)" stroke-width="2" stroke-linecap="round" />
                </svg>
            </div>
        </div>
        <div class="feat-card accent" style="background: var(--amber-bg);">
            <div class="feat-tag" style="background: rgba(201,123,42,.12); color: var(--amber);">Dashboard Guru BK</div>
            <h3 style="color:var(--ink)">Guru BK Punya Akses Penuh</h3>
            <p style="color:var(--ink-60)">Guru Bimbingan Konseling dapat memantau seluruh siswa, melihat hasil analisis, menambah catatan konseling, dan mengekspor laporan untuk sekolah.</p>
            <div class="feat-deco">
                <svg viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="18" cy="14" r="5" stroke="rgba(201,123,42,0.4)" stroke-width="2" />
                    <path d="M8 30C8 24.477 12.477 20 18 20C23.523 20 28 24.477 28 30" stroke="rgba(201,123,42,0.4)" stroke-width="2" stroke-linecap="round" />
                </svg>
            </div>
        </div>
    </div>
</section>

<div class="quote-section">
    <div class="quote-inner">
        <div class="quote-mark">"</div>
        <p class="quote-text">Saya pikir saya cocok di jurusan Hukum karena disuruh orang tua. Ternyata LENTERA bilang Sistem Informasi — dan sekarang saya nggak pernah merasa salah jurusan.</p>
        <!-- <div class="quote-author">Farah Diba — Mahasiswi Sistem Informasi, Universitas Brawijaya</div> -->
    </div>
</div>

<div class="cta-strip">
    <h2>Sudah siap menemukan<br>jurusan yang <em>benar-benar</em> sesuai?</h2>
    <a href="/masuk" class="btn-cta-large">
        Coba LENTERA
        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 8H13M13 8L9 4M13 8L9 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </a>
</div>

@endsection