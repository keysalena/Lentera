@extends('layouts.siswa')

@section('title', 'LENTERA - Hasil Analisis')

@section('dashboard_content')
<div class="dashboard-hasil" style="animation: fadeIn 0.5s ease-in-out;">

    <div style="display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 24px; margin-bottom: 32px;">
        <div>
            <div style="display: inline-flex; align-items: center; gap: 6px; background: rgba(16, 185, 129, 0.1); color: #10B981; padding: 6px 12px; border-radius: 8px; font-size: 12px; font-weight: 700; margin-bottom: 12px;">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 14px; height: 14px;">
                    <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                ANALISIS SELESAI
            </div>
            <h2 style="font-family: 'DM Serif Display', serif; font-size: 32px; color: var(--ink); margin-bottom: 8px;">
                Hasil Eksplorasi Kariermu
            </h2>
            <p style="font-size: 15px; color: var(--ink-60); max-width: 600px;">
                Sistem LENTERA telah memproses integrasi nilai akademik dan ekstraksi karakter tulisan tanganmu. Berikut adalah pemetaan potensimu.
            </p>
        </div>

        <div>
            <button class="btn-secondary" style="display: flex; align-items: center; gap: 8px; background: var(--white); border: 2px solid var(--cream);">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 18px; height: 18px;">
                    <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-3 3m0 0l-3-3m3 3V4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                Unduh Laporan (PDF)
            </button>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 24px; margin-bottom: 24px;">

        <div style="background: var(--white); padding: 32px; border-radius: 20px; border: 1px solid rgba(171, 168, 159, 0.25); box-shadow: 0 4px 24px rgba(87, 94, 112, 0.02); display: flex; flex-direction: column;">
            <h3 style="font-size: 16px; font-weight: 700; color: var(--ink); margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between;">
                Profil Kepribadian (Big Five)
                <span style="font-size: 11px; font-weight: 500; color: var(--ink-30); background: var(--paper); padding: 4px 8px; border-radius: 6px;">Berdasarkan Tulisan Tangan</span>
            </h3>

            <div style="flex: 1; display: flex; align-items: center; justify-content: center; position: relative; min-height: 220px;">
                <svg viewBox="0 0 200 200" style="width: 100%; max-width: 220px; height: auto;">
                    <polygon points="100,10 185,71 153,171 47,171 15,71" fill="none" stroke="var(--cream)" stroke-width="2" />
                    <polygon points="100,30 166,78 141,155 59,155 34,78" fill="none" stroke="var(--cream)" stroke-width="1.5" />
                    <polygon points="100,50 148,85 130,140 70,140 52,85" fill="none" stroke="var(--cream)" stroke-width="1.5" />
                    <line x1="100" y1="100" x2="100" y2="10" stroke="var(--cream)" stroke-width="2" />
                    <line x1="100" y1="100" x2="185" y2="71" stroke="var(--cream)" stroke-width="2" />
                    <line x1="100" y1="100" x2="153" y2="171" stroke="var(--cream)" stroke-width="2" />
                    <line x1="100" y1="100" x2="47" y2="171" stroke="var(--cream)" stroke-width="2" />
                    <line x1="100" y1="100" x2="15" y2="71" stroke="var(--cream)" stroke-width="2" />

                    <polygon points="100,20 160,75 120,160 55,145 35,75" fill="rgba(245, 158, 11, 0.2)" stroke="var(--amber)" stroke-width="3" stroke-linejoin="round" />
                    <circle cx="100" cy="20" r="4" fill="var(--amber)" />
                    <circle cx="160" cy="75" r="4" fill="var(--amber)" />
                    <circle cx="120" cy="160" r="4" fill="var(--amber)" />
                    <circle cx="55" cy="145" r="4" fill="var(--amber)" />
                    <circle cx="35" cy="75" r="4" fill="var(--amber)" />
                </svg>
                <span style="position: absolute; top: 0; left: 50%; transform: translateX(-50%); font-size: 11px; font-weight: 700; color: var(--ink);">Openness</span>
                <span style="position: absolute; top: 35%; right: 0; font-size: 11px; font-weight: 700; color: var(--ink);">Conscientious</span>
                <span style="position: absolute; bottom: 5%; right: 10%; font-size: 11px; font-weight: 700; color: var(--ink);">Extraversion</span>
                <span style="position: absolute; bottom: 5%; left: 10%; font-size: 11px; font-weight: 700; color: var(--ink);">Agreeableness</span>
                <span style="position: absolute; top: 35%; left: 0; font-size: 11px; font-weight: 700; color: var(--ink);">Neuroticism</span>
            </div>
        </div>

        <div style="background: var(--ink); padding: 32px; border-radius: 20px; box-shadow: 0 4px 24px rgba(87, 94, 112, 0.08); display: flex; flex-direction: column; justify-content: space-between; position: relative; overflow: hidden;">
            <div style="position: absolute; right: -20px; top: -40px; width: 160px; height: 160px; border-radius: 50%; border: 20px solid rgba(245, 158, 11, 0.1);"></div>

            <div style="position: relative; z-index: 10;">
                <h3 style="font-size: 13px; font-weight: 700; color: var(--amber-lt); margin-bottom: 8px; letter-spacing: 0.05em; text-transform: uppercase;">
                    Bidang Karier Dominan
                </h3>
                <h2 style="font-family: 'DM Serif Display', serif; font-size: 36px; color: var(--white); line-height: 1.1; margin-bottom: 16px;">
                    Pendidikan & <br>Teknologi (STEM)
                </h2>

                <div style="background: rgba(255, 255, 255, 0.1); border-radius: 12px; padding: 16px; margin-top: 24px;">
                    <h4 style="font-size: 12px; font-weight: 700; color: var(--amber-lt); margin-bottom: 8px; display: flex; align-items: center; gap: 6px;">
                        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 14px; height: 14px;">
                            <path d="M13 10V3L4 14H11V21L20 10H13Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        LENTERA Insight
                    </h4>
                    <p style="font-size: 13.5px; color: rgba(255, 255, 255, 0.85); line-height: 1.6; margin: 0;">
                        Tingkat <em>Openness</em> dan <em>Conscientiousness</em> kamu yang menonjol dari analisis tulisan tangan menunjukkan daya analitis dan ketekunan tinggi. Hal ini tervalidasi dengan sangat kuat oleh nilai capaian akademikmu pada mata pelajaran Matematika dan Informatika.
                    </p>
                </div>
            </div>
        </div>

    </div>

    <div style="background: var(--white); padding: 32px; border-radius: 20px; border: 1px solid rgba(171, 168, 159, 0.25); box-shadow: 0 4px 24px rgba(87, 94, 112, 0.02);">

        <div style="margin-bottom: 24px;">
            <h3 style="font-size: 18px; font-weight: 700; color: var(--ink); margin-bottom: 4px;">Top 3 Rekomendasi Jurusan</h3>
            <p style="font-size: 13px; color: var(--ink-60);">Daftar program studi perguruan tinggi yang memiliki tingkat kecocokan paling tinggi dengan datamu.</p>
        </div>

        <div style="display: flex; flex-direction: column; gap: 16px;">

            <div style="background: var(--amber-bg); border: 1px solid #EDD19B; padding: 20px; border-radius: 14px; display: flex; align-items: center; gap: 20px; transition: transform 0.2s; cursor: pointer;" onmouseover="this.style.transform='translateX(4px)';" onmouseout="this.style.transform='none';">
                <div style="width: 48px; height: 48px; background: var(--amber); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-family: 'DM Serif Display', serif; font-size: 24px; color: var(--white);">
                    1
                </div>
                <div style="flex: 1;">
                    <h4 style="font-size: 16px; font-weight: 700; color: var(--ink); margin-bottom: 4px;">Pendidikan Teknik Informatika</h4>
                    <p style="font-size: 13px; color: var(--ink-60);">Fokus pada pengembangan teknologi komputasi sekaligus ilmu kependidikan.</p>
                </div>
                <div style="text-align: right; min-width: 100px;">
                    <div style="font-size: 24px; font-weight: 800; color: var(--amber); margin-bottom: 4px;">95%</div>
                    <div style="height: 6px; background: rgba(201, 123, 42, 0.15); border-radius: 99px; overflow: hidden;">
                        <div style="height: 100%; width: 95%; background: var(--amber); border-radius: 99px;"></div>
                    </div>
                </div>
            </div>

            <div style="background: var(--paper); border: 1px solid rgba(171, 168, 159, 0.25); padding: 20px; border-radius: 14px; display: flex; align-items: center; gap: 20px; transition: transform 0.2s; cursor: pointer;" onmouseover="this.style.transform='translateX(4px)';" onmouseout="this.style.transform='none';">
                <div style="width: 48px; height: 48px; background: var(--cream); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-family: 'DM Serif Display', serif; font-size: 24px; color: var(--ink-60);">
                    2
                </div>
                <div style="flex: 1;">
                    <h4 style="font-size: 16px; font-weight: 700; color: var(--ink); margin-bottom: 4px;">Teknik Informatika / Ilmu Komputer</h4>
                    <p style="font-size: 13px; color: var(--ink-60);">Fokus murni pada perancangan perangkat lunak, algoritma, dan sistem cerdas.</p>
                </div>
                <div style="text-align: right; min-width: 100px;">
                    <div style="font-size: 20px; font-weight: 800; color: var(--ink); margin-bottom: 4px;">88%</div>
                    <div style="height: 6px; background: var(--cream); border-radius: 99px; overflow: hidden;">
                        <div style="height: 100%; width: 88%; background: var(--ink-30); border-radius: 99px;"></div>
                    </div>
                </div>
            </div>

            <div style="background: var(--paper); border: 1px solid rgba(171, 168, 159, 0.25); padding: 20px; border-radius: 14px; display: flex; align-items: center; gap: 20px; transition: transform 0.2s; cursor: pointer;" onmouseover="this.style.transform='translateX(4px)';" onmouseout="this.style.transform='none';">
                <div style="width: 48px; height: 48px; background: var(--cream); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-family: 'DM Serif Display', serif; font-size: 24px; color: var(--ink-60);">
                    3
                </div>
                <div style="flex: 1;">
                    <h4 style="font-size: 16px; font-weight: 700; color: var(--ink); margin-bottom: 4px;">Sistem Informasi</h4>
                    <p style="font-size: 13px; color: var(--ink-60);">Manajemen data, integrasi teknologi ke dalam proses bisnis, dan analis sistem.</p>
                </div>
                <div style="text-align: right; min-width: 100px;">
                    <div style="font-size: 20px; font-weight: 800; color: var(--ink); margin-bottom: 4px;">84%</div>
                    <div style="height: 6px; background: var(--cream); border-radius: 99px; overflow: hidden;">
                        <div style="height: 100%; width: 84%; background: var(--ink-30); border-radius: 99px;"></div>
                    </div>
                </div>
            </div>

        </div>

        <div style="margin-top: 24px; padding: 16px; background: var(--paper); border-radius: 10px; border-left: 4px solid var(--amber); display: flex; gap: 12px; align-items: flex-start;">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 20px; height: 20px; color: var(--amber); flex-shrink: 0; margin-top: 2px;">
                <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M12 16V12M12 8H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p style="font-size: 13px; color: var(--ink-60); line-height: 1.5; margin: 0;">
                <strong>Tindak Lanjut:</strong> Hasil analisis ini adalah rekomendasi awal dari mesin. Langkah berikutnya, hasil ini akan divalidasi oleh <strong>Guru BK</strong> di sekolahmu sebagai bahan pertimbangan dalam sesi konsultasi tatap muka.
            </p>
        </div>
        <div style="margin-top: 12px; padding: 12px 16px; background: rgba(87, 94, 112, 0.04); border-radius: 10px; display: flex; gap: 12px; align-items: flex-start; border: 1px dashed var(--ink-30);">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 18px; height: 18px; color: var(--ink-30); flex-shrink: 0; margin-top: 2px;">
                <path d="M13 16H12V12H11M12 8H12.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            <p style="font-size: 12px; color: var(--ink-60); line-height: 1.5; margin: 0;">
                <strong>Catatan Sistem:</strong> Persentase kecocokan di atas merupakan estimasi komputasional berdasarkan pola datamu, bukan sebuah kepastian atau jaminan mutlak. Jadikan informasi ini sebagai kompas referensi untuk mengenali potensimu lebih dalam, bukan sebagai satu-satunya penentu masa depanmu.
            </p>
        </div>

    </div>

</div>

<style>
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(15px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>
@endsection