@extends('layouts.siswa')

@section('title', 'LENTERA - Input Eksplorasi')

@section('dashboard_content')
<div class="dashboard-input-wizard" style="animation: fadeIn 0.4s ease-in-out;">
    
    <div style="margin-bottom: 32px;">
        <h2 style="font-family: 'DM Serif Display', serif; font-size: 32px; color: var(--ink); margin-bottom: 8px;">
            Input Eksplorasi Data
        </h2>
        <p style="font-size: 15px; color: var(--ink-60); max-width: 600px;">
            Lengkapi tahapan pengisian data di bawah ini. Tahap 1 wajib diisi untuk analisis karakter, sedangkan Tahap 2 dan 3 bersifat opsional namun sangat disarankan untuk akurasi rekomendasi.
        </p>
    </div>

    <div style="display: flex; align-items: center; margin-bottom: 32px; max-width: 700px;">
        <div id="indicator-step-1" style="display: flex; align-items: center; gap: 10px;">
            <div class="step-circle active" style="width: 36px; height: 36px; border-radius: 50%; background: var(--amber); color: var(--white); display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 700; transition: all 0.3s;">1</div>
            <span class="step-text active" style="font-size: 14px; font-weight: 700; color: var(--ink); transition: all 0.3s; white-space: nowrap;">Tulisan Reflektif</span>
        </div>
        
        <div style="height: 2px; background: var(--cream); flex: 1; margin: 0 16px; position: relative;">
            <div id="progress-line-1" style="position: absolute; top: 0; left: 0; height: 100%; width: 0%; background: var(--amber); transition: width 0.4s ease;"></div>
        </div>
        
        <div id="indicator-step-2" style="display: flex; align-items: center; gap: 10px;">
            <div class="step-circle inactive" style="width: 36px; height: 36px; border-radius: 50%; background: var(--white); color: var(--ink-30); border: 2px solid var(--cream); display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 700; transition: all 0.3s;">2</div>
            <span class="step-text inactive" style="font-size: 14px; font-weight: 500; color: var(--ink-30); transition: all 0.3s; white-space: nowrap;">Data Akademik</span>
        </div>

        <div style="height: 2px; background: var(--cream); flex: 1; margin: 0 16px; position: relative;">
            <div id="progress-line-2" style="position: absolute; top: 0; left: 0; height: 100%; width: 0%; background: var(--amber); transition: width 0.4s ease;"></div>
        </div>

        <div id="indicator-step-3" style="display: flex; align-items: center; gap: 10px;">
            <div class="step-circle inactive" style="width: 36px; height: 36px; border-radius: 50%; background: var(--white); color: var(--ink-30); border: 2px solid var(--cream); display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 700; transition: all 0.3s;">3</div>
            <span class="step-text inactive" style="font-size: 14px; font-weight: 500; color: var(--ink-30); transition: all 0.3s; white-space: nowrap;">Kemampuan</span>
        </div>
    </div>

    <div style="background: var(--white); padding: 40px; border-radius: 20px; border: 1px solid rgba(171, 168, 159, 0.25); box-shadow: 0 4px 24px rgba(87, 94, 112, 0.02); max-width: 900px;">
        
        <form action="#" method="POST" id="exploration-form" enctype="multipart/form-data">
            @csrf

            <div id="step-1-content">
                <div style="margin-bottom: 28px; padding-bottom: 20px; border-bottom: 1px solid var(--cream);">
                    <div style="display: inline-block; background: #FFF5F5; color: #BA1A1A; font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 6px; margin-bottom: 8px;">DOKUMEN WAJIB</div>
                    <h3 style="font-size: 18px; font-weight: 700; color: var(--ink); margin-bottom: 6px;">Unggah Dokumen Tulisan Tangan</h3>
                    <p style="font-size: 13px; color: var(--ink-60); line-height: 1.6;">
                        Tuliskan narasi reflektif (±100-150 kata) menggunakan pulpen di kertas putih. Sistem akan mengekstraksi skor <i>Big Five Personality</i> Anda dari unggahan ini.
                    </p>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px; align-items: stretch;">
                    <div style="display: flex; flex-direction: column;">
                        <label style="font-size: 13px; font-weight: 700; color: var(--ink); margin-bottom: 12px;">Area Unggah Foto Tulisan</label>
                        <div class="dropzone-area" id="dropzone-container" style="border: 2px dashed var(--ink-30); background: var(--paper); border-radius: 14px; padding: 48px 24px; text-align: center; cursor: pointer; transition: all 0.2s; flex: 1; display: flex; flex-direction: column; justify-content: center;" onclick="document.getElementById('tulisan_tangan').click()">
                            <input type="file" id="tulisan_tangan" name="tulisan_tangan" accept="image/png, image/jpeg, image/jpg" style="display: none;" onchange="previewFileName(this, 'dropzone-text-1', 'file-preview-1', 'file-name-display-1', this.parentElement)">
                            
                            <div id="dropzone-text-1">
                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 48px; height: 48px; color: var(--amber); margin: 0 auto 16px;">
                                    <path d="M12 16V8M12 8L9 11M12 8L15 11M3 15V18C3 19.1046 3.89543 20 5 20H19C20.1046 20 21 19.1046 21 18V15" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span style="font-size: 14px; font-weight: 700; color: var(--ink); display: block; margin-bottom: 6px;">Pilih foto tulisan Anda</span>
                                <span style="font-size: 12px; color: var(--ink-30);">Format JPG/PNG (Maks 5MB)</span>
                            </div>

                            <div id="file-preview-1" style="display: none; align-items: center; justify-content: center; gap: 10px; flex-direction: column;">
                                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 40px; height: 40px; color: #10B981;">
                                    <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <span id="file-name-display-1" style="font-size: 14px; font-weight: 700; color: var(--ink);">nama-file.jpg</span>
                            </div>
                        </div>
                    </div>

                    <div style="background: var(--amber-bg); border: 1px solid #EDD19B; border-radius: 14px; padding: 24px; position: relative;">
                        <div style="position: absolute; top: -12px; right: 24px; background: var(--amber); color: var(--white); padding: 4px 12px; border-radius: 99px; font-size: 11px; font-weight: 700; letter-spacing: 0.05em;">CONTOH</div>
                        <h4 style="font-size: 14px; font-weight: 700; color: var(--ink); margin-bottom: 12px;">
                            Referensi Topik Narasi
                        </h4>
                        <div style="background: rgba(255, 255, 255, 0.6); padding: 16px; border-radius: 10px;">
                            <p style="font-family: 'DM Serif Display', serif; font-style: italic; font-size: 14px; color: var(--ink-60); line-height: 1.6; margin: 0;">
                                "Bagi saya, kegiatan yang paling bermakna adalah ketika saya berhasil memecahkan masalah logika atau merakit sesuatu. Sejak SMP, saya sangat suka membongkar perangkat dan mencari tahu bagaimana komponen-komponen di dalamnya bekerja..."
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="step-2-content" style="display: none;">
                <div style="margin-bottom: 28px; padding-bottom: 20px; border-bottom: 1px solid var(--cream);">
                    <div style="display: inline-block; background: rgba(201, 123, 42, 0.12); color: var(--amber); font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 6px; margin-bottom: 8px;">DATA OPSIONAL</div>
                    <h3 style="font-size: 18px; font-weight: 700; color: var(--ink); margin-bottom: 6px;">Data Nilai Akademik (Rapor)</h3>
                    <p style="font-size: 13px; color: var(--ink-60);">Masukkan rata-rata nilai rapor (skala 0 - 100). Kosongkan jika Anda belum memiliki datanya.</p>
                </div>

 <!-- Bagian A: Mapel Inti -->
                <h4 style="font-size: 14px; font-weight: 700; color: var(--ink); margin-bottom: 16px; padding-left: 8px; border-left: 3px solid var(--amber);">A. Mata Pelajaran Inti</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 32px;">
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Agama</label>
                        <input type="number" name="agama" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Pancasila</label>
                        <input type="number" name="pancasila" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Bahasa Indonesia</label>
                        <input type="number" name="bahasa_indonesia" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Matematika</label>
                        <input type="number" name="matematika" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">IPA</label>
                        <input type="number" name="ipa" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">IPS</label>
                        <input type="number" name="ips" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Bahasa Inggris</label>
                        <input type="number" name="bahasa_inggris" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">PJOK</label>
                        <input type="number" name="pjok" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Informatika</label>
                        <input type="number" name="informatika" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Seni Budaya</label>
                        <input type="number" name="seni_budaya" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                </div>

                <!-- Bagian B: Literasi, Numerasi & Karakter (P5) -->
                <h4 style="font-size: 14px; font-weight: 700; color: var(--ink); margin-bottom: 16px; padding-left: 8px; border-left: 3px solid var(--amber);">B. Literasi, Numerasi & Pengembangan Karakter</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Logika</label>
                        <input type="number" name="logika" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Kreativitas</label>
                        <input type="number" name="kreativitas" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Komunikasi</label>
                        <input type="number" name="komunikasi" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Kepemimpinan</label>
                        <input type="number" name="kepemimpinan" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Problem Solving</label>
                        <input type="number" name="problem_solving" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Teamwork</label>
                        <input type="number" name="teamwork" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Literasi</label>
                        <input type="number" name="literasi" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Numerasi</label>
                        <input type="number" name="numerasi" min="0" max="100" placeholder="0 - 100" class="input-form">
                    </div>
                </div>
            </div>

            <div id="step-3-content" style="display: none;">
                <div style="margin-bottom: 28px; padding-bottom: 20px; border-bottom: 1px solid var(--cream);">
                    <div style="display: inline-block; background: rgba(201, 123, 42, 0.12); color: var(--amber); font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 6px; margin-bottom: 8px;">DATA OPSIONAL</div>
                    <h3 style="font-size: 18px; font-weight: 700; color: var(--ink); margin-bottom: 6px;">Penilaian Minat & Kemampuan</h3>
                    <p style="font-size: 13px; color: var(--ink-60);">
                        Seberapa baik kemampuan Anda pada bidang berikut? Pilih angka <strong>1 hingga 10</strong>. Kosongkan untuk kategori yang dirasa kurang relevan.
                    </p>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Komunikasi</label>
                        <select name="komunikasi" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Kepemimpinan</label>
                        <select name="kepemimpinan" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Kreativitas</label>
                        <select name="kreativitas" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Logika</label>
                        <select name="logika" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Teknologi</label>
                        <select name="teknologi" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Riset</label>
                        <select name="riset" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Seni</label>
                        <select name="seni" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Olahraga</label>
                        <select name="olahraga" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Organisasi</label>
                        <select name="organisasi" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Kewirausahaan</label>
                        <select name="kewirausahaan" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Kerja Tim</label>
                        <select name="kerja_tim" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; font-size: 13px; font-weight: 600; color: var(--ink); margin-bottom: 8px;">Problem Solving</label>
                        <select name="problem_solving" class="input-form" style="cursor: pointer;">
                            <option value="" selected>Pilih Skor...</option>
                            <option value="1">1</option><option value="2">2</option><option value="3">3</option>
                            <option value="4">4</option><option value="5">5</option><option value="6">6</option>
                            <option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
                        </select>
                    </div>

                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 32px; padding-top: 24px; border-top: 1px solid var(--cream);">
                <button type="button" id="btn-prev" class="btn-secondary" style="display: none; padding: 12px 24px; font-size: 14px; font-weight: 600; border-radius: 10px;">
                    Kembali
                </button>
                <button type="button" id="btn-next" style="background: var(--amber); color: var(--white); border: none; padding: 12px 28px; font-size: 14px; font-weight: 700; border-radius: 10px; cursor: pointer; transition: opacity 0.2s;">
                    Selanjutnya
                </button>
            </div>

        </form>
    </div>
</div>

<script>
    // --- LOGIKA WIZARD STEP ---
    const step1 = document.getElementById('step-1-content');
    const step2 = document.getElementById('step-2-content');
    const step3 = document.getElementById('step-3-content');
    
    const btnNext = document.getElementById('btn-next');
    const btnPrev = document.getElementById('btn-prev');
    const form = document.getElementById('exploration-form');
    
    const progressLine1 = document.getElementById('progress-line-1');
    const progressLine2 = document.getElementById('progress-line-2');
    
    const circle2 = document.querySelector('#indicator-step-2 .step-circle');
    const text2 = document.querySelector('#indicator-step-2 .step-text');
    const circle3 = document.querySelector('#indicator-step-3 .step-circle');
    const text3 = document.querySelector('#indicator-step-3 .step-text');
    
    let currentStep = 1;

    btnNext.addEventListener('click', function() {
        if (currentStep === 1) {
            // Validasi Step 1: Upload File (Wajib)
            const fileInput = document.getElementById('tulisan_tangan');
            const dropzoneContainer = document.getElementById('dropzone-container');
            
            if(fileInput.files.length === 0) {
                alert("Tahap ini wajib! Harap unggah foto tulisan tangan Anda.");
                dropzoneContainer.style.borderColor = '#BA1A1A';
                dropzoneContainer.style.backgroundColor = '#FFF5F5';
                return;
            }

            // Pindah ke Step 2
            step1.style.display = 'none';
            step2.style.display = 'block';
            step3.style.display = 'none';
            
            btnPrev.style.display = 'block';
            btnNext.innerText = 'Selanjutnya';
            
            progressLine1.style.width = '100%';
            circle2.style.background = 'var(--amber)';
            circle2.style.color = 'var(--white)';
            circle2.style.borderColor = 'var(--amber)';
            text2.style.color = 'var(--ink)';
            text2.style.fontWeight = '700';

            currentStep = 2;
        } 
        else if (currentStep === 2) {
            // Pindah ke Step 3
            step1.style.display = 'none';
            step2.style.display = 'none';
            step3.style.display = 'block';
            
            btnNext.innerText = 'Selesai & Analisis';
            
            progressLine2.style.width = '100%';
            circle3.style.background = 'var(--amber)';
            circle3.style.color = 'var(--white)';
            circle3.style.borderColor = 'var(--amber)';
            text3.style.color = 'var(--ink)';
            text3.style.fontWeight = '700';
            
            currentStep = 3;
        }
        else if (currentStep === 3) {
            // Submit form
            btnNext.innerText = 'Memproses...';
            btnNext.style.opacity = '0.7';
            form.submit();
        }
    });

    btnPrev.addEventListener('click', function() {
        if (currentStep === 2) {
            // Kembali ke Step 1
            step2.style.display = 'none';
            step1.style.display = 'block';
            
            btnPrev.style.display = 'none';
            btnNext.innerText = 'Selanjutnya';
            
            progressLine1.style.width = '0%';
            circle2.style.background = 'var(--white)';
            circle2.style.color = 'var(--ink-30)';
            circle2.style.borderColor = 'var(--cream)';
            text2.style.color = 'var(--ink-30)';
            text2.style.fontWeight = '500';
            
            currentStep = 1;
        }
        else if (currentStep === 3) {
            // Kembali ke Step 2
            step3.style.display = 'none';
            step2.style.display = 'block';
            
            btnNext.innerText = 'Selanjutnya';
            
            progressLine2.style.width = '0%';
            circle3.style.background = 'var(--white)';
            circle3.style.color = 'var(--ink-30)';
            circle3.style.borderColor = 'var(--cream)';
            text3.style.color = 'var(--ink-30)';
            text3.style.fontWeight = '500';
            
            currentStep = 2;
        }
    });

    // Preview File
    function previewFileName(input, textId, previewId, displayId, parentElement) {
        const dropzoneText = document.getElementById(textId);
        const filePreview = document.getElementById(previewId);
        const fileNameDisplay = document.getElementById(displayId);

        if (input.files && input.files[0]) {
            dropzoneText.style.display = 'none';
            filePreview.style.display = 'flex';
            fileNameDisplay.innerText = input.files[0].name;
            parentElement.style.borderColor = '#10B981';
            parentElement.style.backgroundColor = '#F0FDF4';
        }
    }
</script>

<style>
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .dropzone-area:hover {
        border-color: var(--amber) !important;
        background-color: var(--amber-bg) !important;
    }
    .input-form {
        width: 100%; 
        padding: 12px 16px; 
        border: 1px solid var(--ink-30); 
        border-radius: 10px; 
        font-size: 14px; 
        background: var(--paper); 
        outline: none;
    }
    .input-form:focus {
        border-color: var(--amber) !important;
        box-shadow: 0 0 0 3px rgba(201, 123, 42, 0.15);
    }
</style>
@endsection